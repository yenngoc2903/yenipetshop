<!-- Start Footer -->
<div class="footer">
      <div class="slogan">
        <p>YeniPetShop đem đến yêu thương, bạn đem đến ngôi nhà.</p>
        <p>----------</p>
      </div>
      <div class="box">
        <div class="item">
          <p class="name">- Địa chỉ:&nbsp;</p>
          <a href="https://maps.app.goo.gl/3ZhuTvYKksEdqoi27"> Khu II, Đ. 3 Tháng 2, Xuân Khánh, Ninh Kiều, Cần Thơ, Việt Nam</a>
        </div>
        <div class="item">
          <p class="name">- Hotline:&nbsp;</p>
          <p>036 72 79 433</p>
        </div>
        <div class="item">
          <p class="name">- Mail:&nbsp;</p>
          <p>cskh@yeni.com</p>
        </div>
      </div>
      <div class="follow">
        <i class="fa-brands fa-square-facebook fa-xl" style="color: #000000;"></i>
        <i class="fa-brands fa-square-instagram fa-xl" style="color: #000000;"></i>
        <i class="fa-brands fa-tiktok fa-xl" style="color: #000000;"></i>
      </div>
</div>
    <!-- End Footer -->